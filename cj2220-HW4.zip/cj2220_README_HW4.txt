main.py is the Information Retrieval System developed for Homework 4 (HW4). This system calculates TF-IDF vectors, performs cosine similarity calculations.

requirements
------------
this program is tested on Python 3.9
packages required:
nltk
nltk.stem

----------------
The program prints the cosine similarities. So to run the program, you can use the following command:
python main.py > output.txt

query and document collection are assumed to be in the same directory as the main.py file, named as cran.qry and cran.all.1400 respectively.